#!/bin/bash

source ../venv/bin/activate

PYTHON_SEARCH_PATH=../ python dump_ancients_performance.py "317827583044"
PYTHON_SEARCH_PATH=../ python dump_ancients_performance.py "356482285618"
PYTHON_SEARCH_PATH=../ python dump_ancients_performance.py "373662155436"

